package com.exercicios.rest;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface ProdutoRepository {

    List<Produto> findAll();
    Optional<Produto> findById(UUID id);
    Produto save(Produto produto);
    void deleteById(UUID id);
}
