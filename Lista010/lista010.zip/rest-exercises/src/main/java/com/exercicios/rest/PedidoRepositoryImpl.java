package com.exercicios.rest;

import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public class PedidoRepositoryImpl implements PedidoRepository {

    private final List<Pedido> pedidos = new ArrayList<>();

    public PedidoRepositoryImpl() {
        pedidos.add(new Pedido(UUID.randomUUID(), 100.00));
        pedidos.add(new Pedido(UUID.randomUUID(), 250.50));
    }

    @Override
    public List<Pedido> findAll() {
        return pedidos;
    }

    @Override
    public Optional<Pedido> findById(UUID id) {
        return pedidos.stream()
                .filter(p -> p.getId().equals(id))
                .findFirst();
    }

    @Override
    public Pedido save(Pedido pedido) {
        Optional<Pedido> existing = findById(pedido.getId());
        if (existing.isPresent()) {
            Pedido p = existing.get();
            p.setClienteId(pedido.getClienteId());
            p.setValorTotal(pedido.getValorTotal());
            return p;
        } else {
            pedidos.add(pedido);
            return pedido;
        }
    }

    @Override
    public void deleteById(UUID id) {
        pedidos.removeIf(p -> p.getId().equals(id));
    }
}
