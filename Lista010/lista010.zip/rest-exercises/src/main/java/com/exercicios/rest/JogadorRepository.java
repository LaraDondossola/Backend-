package com.exercicios.rest;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface JogadorRepository {

    List<Jogador> findAll();
    Optional<Jogador> findById(UUID id);
    Jogador save(Jogador jogador);
    void deleteById(UUID id);
    List<Jogador> findByNome(String nome);
}
