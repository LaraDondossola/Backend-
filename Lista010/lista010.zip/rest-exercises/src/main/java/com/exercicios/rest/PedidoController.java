package com.exercicios.rest;

import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/pedidos")
public class PedidoController {

    private final PedidoRepository repository;

    public PedidoController(PedidoRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<Pedido> getPedidos() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public Pedido getPedido(@PathVariable UUID id) {
        return repository.findById(id).orElse(null);
    }

    @PostMapping
    public Pedido criarPedido(@RequestBody Pedido pedido) {
        return repository.save(pedido);
    }

    @PatchMapping("/{id}")
    public Pedido atualizarPedido(@PathVariable UUID id, @RequestBody Pedido pedido) {
        pedido.setId(id);
        return repository.save(pedido);
    }

    @DeleteMapping("/{id}")
    public void deletarPedido(@PathVariable UUID id) {
        repository.deleteById(id);
    }
}
