package com.exercicios.rest;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface PedidoRepository {

    List<Pedido> findAll();
    Optional<Pedido> findById(UUID id);
    Pedido save(Pedido pedido);
    void deleteById(UUID id);
}
