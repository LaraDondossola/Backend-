package com.exercicios.rest;

import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public class ProdutoRepositoryImpl implements ProdutoRepository {

    private final List<Produto> produtos = new ArrayList<>();

    public ProdutoRepositoryImpl() {
        produtos.add(new Produto("Notebook", 3500.00));
        produtos.add(new Produto("Mouse", 50.00));
        produtos.add(new Produto("Teclado", 150.00));
    }

    @Override
    public List<Produto> findAll() {
        return produtos;
    }

    @Override
    public Optional<Produto> findById(UUID id) {
        return produtos.stream()
                .filter(p -> p.getId().equals(id))
                .findFirst();
    }

    @Override
    public Produto save(Produto produto) {
        Optional<Produto> existing = findById(produto.getId());
        if (existing.isPresent()) {
            Produto p = existing.get();
            p.setNome(produto.getNome());
            p.setPreco(produto.getPreco());
            return p;
        } else {
            produtos.add(produto);
            return produto;
        }
    }

    @Override
    public void deleteById(UUID id) {
        produtos.removeIf(p -> p.getId().equals(id));
    }
}
