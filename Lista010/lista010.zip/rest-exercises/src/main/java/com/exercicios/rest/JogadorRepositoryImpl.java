package com.exercicios.rest;

import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Repository
public class JogadorRepositoryImpl implements JogadorRepository {

    private final List<Jogador> jogadores = new ArrayList<>();

    public JogadorRepositoryImpl() {
        jogadores.add(new Jogador("Ronaldo", "Atacante", 45));
        jogadores.add(new Jogador("Rivaldo", "Meia", 50));
        jogadores.add(new Jogador("Roberto Carlos", "Lateral", 49));
    }

    @Override
    public List<Jogador> findAll() {
        return jogadores;
    }

    @Override
    public Optional<Jogador> findById(UUID id) {
        return jogadores.stream()
                .filter(j -> j.getId().equals(id))
                .findFirst();
    }

    @Override
    public Jogador save(Jogador jogador) {
        Optional<Jogador> existing = findById(jogador.getId());
        if (existing.isPresent()) {
            Jogador j = existing.get();
            j.setNome(jogador.getNome());
            j.setPosicao(jogador.getPosicao());
            j.setIdade(jogador.getIdade());
            return j;
        } else {
            jogadores.add(jogador);
            return jogador;
        }
    }

    @Override
    public void deleteById(UUID id) {
        jogadores.removeIf(j -> j.getId().equals(id));
    }

    @Override
    public List<Jogador> findByNome(String nome) {
        return jogadores.stream()
                .filter(j -> j.getNome().toLowerCase().contains(nome.toLowerCase()))
                .collect(Collectors.toList());
    }
}
