package com.exercicios.rest;

import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/jogadores")
public class JogadorController {

    private final JogadorRepository repository;

    public JogadorController(JogadorRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<Jogador> getJogadores(@RequestParam(required = false) String nome) {
        if (nome != null) {
            return repository.findByNome(nome);
        }
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public Jogador getJogador(@PathVariable UUID id) {
        return repository.findById(id).orElse(null);
    }

    @PostMapping
    public Jogador criarJogador(@RequestBody Jogador jogador) {
        return repository.save(jogador);
    }

    @DeleteMapping("/{id}")
    public void deletarJogador(@PathVariable UUID id) {
        repository.deleteById(id);
    }
}
