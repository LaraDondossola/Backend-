package com.exercicios.rest;

import java.time.LocalDateTime;
import java.util.UUID;

public class Pedido {

    private UUID id;
    private UUID clienteId;
    private LocalDateTime dataPedido;
    private double valorTotal;

    public Pedido(UUID clienteId, double valorTotal) {
        this.id = UUID.randomUUID();
        this.clienteId = clienteId;
        this.dataPedido = LocalDateTime.now();
        this.valorTotal = valorTotal;
    }

    public UUID getId() {
        return id;
    }

    public UUID getClienteId() {
        return clienteId;
    }

    public void setClienteId(UUID clienteId) {
        this.clienteId = clienteId;
    }

    public LocalDateTime getDataPedido() {
        return dataPedido;
    }

    public void setDataPedido(LocalDateTime dataPedido) {
        this.dataPedido = dataPedido;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }
}
