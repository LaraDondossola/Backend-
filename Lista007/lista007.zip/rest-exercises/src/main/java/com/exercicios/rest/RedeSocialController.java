package com.exercicios.rest;

import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/rede-social")
public class RedeSocialController {

    private final List<Usuario> usuarios;

    public RedeSocialController() {
        usuarios = new ArrayList<>();
        usuarios.add(new Usuario("Alice", "alice@email.com"));
        usuarios.add(new Usuario("Bob", "bob@email.com"));
    }

    @GetMapping("/usuarios")
    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    @GetMapping("/usuarios/{id}/tweets")
    public List<Tweet> getTweetsUsuario(@PathVariable UUID id) {
        Usuario usuario = usuarios.stream()
                .filter(u -> u.getId().equals(id))
                .findFirst()
                .orElse(null);

        if (usuario == null) {
            return null;
        }

        return usuario.getTweets();
    }

    @PostMapping("/usuarios/{id}/tweets")
    public Tweet criarTweet(@PathVariable UUID id, @RequestBody TweetRequest request) {
        Usuario usuario = usuarios.stream()
                .filter(u -> u.getId().equals(id))
                .findFirst()
                .orElse(null);

        if (usuario == null) {
            return null;
        }

        Tweet novoTweet = new Tweet(request.getMensagem());
        usuario.getTweets().add(novoTweet);

        return novoTweet;
    }

    @PatchMapping("/usuarios/{id}/tweets/{tweetId}")
    public Tweet atualizarTweet(@PathVariable UUID id, @PathVariable UUID tweetId, @RequestBody TweetRequest request) {
        Usuario usuario = usuarios.stream()
                .filter(u -> u.getId().equals(id))
                .findFirst()
                .orElse(null);

        if (usuario == null) {
            return null;
        }

        Tweet tweet = usuario.getTweets().stream()
                .filter(t -> t.getTweetId().equals(tweetId))
                .findFirst()
                .orElse(null);

        if (tweet == null) {
            return null;
        }

        tweet.setMensagem(request.getMensagem());
        tweet.setEditado(true);

        return tweet;
    }

    @DeleteMapping("/usuarios/{id}/tweets/{tweetId}")
    public boolean removerTweet(@PathVariable UUID id, @PathVariable UUID tweetId) {
        Usuario usuario = usuarios.stream()
                .filter(u -> u.getId().equals(id))
                .findFirst()
                .orElse(null);

        if (usuario == null) {
            return false;
        }

        return usuario.getTweets().removeIf(t -> t.getTweetId().equals(tweetId));
    }

    public static class TweetRequest {
        private String mensagem;

        public String getMensagem() {
            return mensagem;
        }

        public void setMensagem(String mensagem) {
            this.mensagem = mensagem;
        }
    }
}
