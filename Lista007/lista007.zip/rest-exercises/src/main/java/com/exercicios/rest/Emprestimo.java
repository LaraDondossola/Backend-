package com.exercicios.rest;

import java.time.LocalDateTime;
import java.util.UUID;

public class Emprestimo {

    private UUID emprestimoId;
    private UUID livroId;
    private UUID usuarioId;
    private LocalDateTime dataEmprestimo;

    public Emprestimo(UUID livroId, UUID usuarioId) {
        this.emprestimoId = UUID.randomUUID();
        this.livroId = livroId;
        this.usuarioId = usuarioId;
        this.dataEmprestimo = LocalDateTime.now();
    }

    public UUID getEmprestimoId() {
        return emprestimoId;
    }

    public UUID getLivroId() {
        return livroId;
    }

    public UUID getUsuarioId() {
        return usuarioId;
    }

    public LocalDateTime getDataEmprestimo() {
        return dataEmprestimo;
    }
}
