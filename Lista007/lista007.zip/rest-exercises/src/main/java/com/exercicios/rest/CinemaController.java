package com.exercicios.rest;

import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/cinema")
public class CinemaController {

    private final List<Filme> filmes;
    private final List<Ingresso> ingressosVendidos;

    public CinemaController() {
        filmes = new ArrayList<>();
        filmes.add(new Filme("Aventura Perdida", "Aventura", 100));
        filmes.add(new Filme("Comédia Romântica", "Comédia", 50));

        ingressosVendidos = new ArrayList<>();
    }

    // CRUD de Filmes

    @GetMapping("/filmes")
    public List<Filme> getFilmes() {
        return filmes;
    }

    @PostMapping("/filmes")
    public Filme criarFilme(@RequestBody FilmeRequest request) {
        Filme novoFilme = new Filme(request.getTitulo(), request.getGenero(), request.getCapacidade());
        filmes.add(novoFilme);
        return novoFilme;
    }

    @PatchMapping("/filmes/{id}")
    public Filme atualizarFilme(@PathVariable UUID id, @RequestBody FilmeRequest request) {
        Filme filme = filmes.stream()
                .filter(f -> f.getId().equals(id))
                .findFirst()
                .orElse(null);

        if (filme == null) {
            return null;
        }

        if (request.getTitulo() != null) {
            filme.setTitulo(request.getTitulo());
        }
        if (request.getGenero() != null) {
            filme.setGenero(request.getGenero());
        }
        if (request.getCapacidade() > 0) {
            filme.setCapacidade(request.getCapacidade());
        }

        return filme;
    }

    @DeleteMapping("/filmes/{id}")
    public boolean removerFilme(@PathVariable UUID id) {
        return filmes.removeIf(f -> f.getId().equals(id));
    }

    // Ingressos

    @PostMapping("/filmes/{id}/ingressos")
    public Ingresso comprarIngresso(@PathVariable UUID id, @RequestBody IngressoRequest request) {
        Filme filme = filmes.stream()
                .filter(f -> f.getId().equals(id))
                .findFirst()
                .orElse(null);

        if (filme == null || filme.getAssentosOcupados() >= filme.getCapacidade()) {
            return null;
        }

        filme.setAssentosOcupados(filme.getAssentosOcupados() + 1);
        Ingresso novoIngresso = new Ingresso(id, request.getAssentoNumero());
        ingressosVendidos.add(novoIngresso);

        return novoIngresso;
    }

    @DeleteMapping("/filmes/{id}/ingressos/{ingressoId}")
    public boolean devolverIngresso(@PathVariable UUID id, @PathVariable UUID ingressoId) {
        Filme filme = filmes.stream()
                .filter(f -> f.getId().equals(id))
                .findFirst()
                .orElse(null);

        if (filme == null || filme.getAssentosOcupados() <= 0) {
            return false;
        }

        boolean removido = ingressosVendidos.removeIf(i -> i.getIngressoId().equals(ingressoId) && i.getFilmeId().equals(id));

        if (removido) {
            filme.setAssentosOcupados(filme.getAssentosOcupados() - 1);
            return true;
        }

        return false;
    }

    public static class FilmeRequest {
        private String titulo;
        private String genero;
        private int capacidade;

        public String getTitulo() {
            return titulo;
        }

        public void setTitulo(String titulo) {
            this.titulo = titulo;
        }

        public String getGenero() {
            return genero;
        }

        public void setGenero(String genero) {
            this.genero = genero;
        }

        public int getCapacidade() {
            return capacidade;
        }

        public void setCapacidade(int capacidade) {
            this.capacidade = capacidade;
        }
    }

    public static class IngressoRequest {
        private int assentoNumero;

        public int getAssentoNumero() {
            return assentoNumero;
        }

        public void setAssentoNumero(int assentoNumero) {
            this.assentoNumero = assentoNumero;
        }
    }
}
