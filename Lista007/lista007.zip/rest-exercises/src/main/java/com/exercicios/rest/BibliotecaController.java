package com.exercicios.rest;

import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/biblioteca")
public class BibliotecaController {

    private final List<Livro> livrosDisponiveis;
    private final List<Emprestimo> emprestimosAtivos;

    public BibliotecaController() {
        livrosDisponiveis = new ArrayList<>();
        livrosDisponiveis.add(new Livro("O Senhor dos Anéis", "J.R.R. Tolkien"));
        livrosDisponiveis.add(new Livro("1984", "George Orwell"));
        livrosDisponiveis.add(new Livro("O Pequeno Príncipe", "Antoine de Saint-Exupéry"));

        emprestimosAtivos = new ArrayList<>();
    }

    @GetMapping("/livros")
    public List<Livro> getLivrosDisponiveis() {
        return livrosDisponiveis;
    }

    @GetMapping("/emprestados")
    public List<Emprestimo> getEmprestimosAtivos() {
        return emprestimosAtivos;
    }

    @PostMapping("/emprestados")
    public Emprestimo realizarEmprestimo(@RequestBody EmprestimoRequest request) {
        UUID livroId = request.getLivroId();
        UUID usuarioId = request.getUsuarioId();

        Livro livroParaEmprestar = livrosDisponiveis.stream()
                .filter(livro -> livro.getId().equals(livroId))
                .findFirst()
                .orElse(null);

        if (livroParaEmprestar == null) {
            return null;
        }

        livrosDisponiveis.remove(livroParaEmprestar);
        Emprestimo novoEmprestimo = new Emprestimo(livroId, usuarioId);
        emprestimosAtivos.add(novoEmprestimo);

        return novoEmprestimo;
    }

    @DeleteMapping("/emprestados/{emprestimoId}")
    public Livro devolverLivro(@PathVariable UUID emprestimoId) {
        Emprestimo emprestimoParaRemover = emprestimosAtivos.stream()
                .filter(emprestimo -> emprestimo.getEmprestimoId().equals(emprestimoId))
                .findFirst()
                .orElse(null);

        if (emprestimoParaRemover == null) {
            return null;
        }

        emprestimosAtivos.remove(emprestimoParaRemover);

        // Simulação de busca do livro para devolver (o livro original não tem o autor e título)
        // Em um cenário real, o livro teria que ser recuperado de um banco de dados ou ter seus dados armazenados no empréstimo.
        // Como o requisito não especifica, vou criar um livro mock com o ID.
        Livro livroDevolvido = new Livro("Livro Devolvido", "Autor Desconhecido");
        livroDevolvido.setTitulo("Livro Devolvido (ID: " + emprestimoParaRemover.getLivroId() + ")");
        livrosDisponiveis.add(livroDevolvido);

        return livroDevolvido;
    }

    public static class EmprestimoRequest {
        private UUID livroId;
        private UUID usuarioId;

        public UUID getLivroId() {
            return livroId;
        }

        public void setLivroId(UUID livroId) {
            this.livroId = livroId;
        }

        public UUID getUsuarioId() {
            return usuarioId;
        }

        public void setUsuarioId(UUID usuarioId) {
            this.usuarioId = usuarioId;
        }
    }
}
