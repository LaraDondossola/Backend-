package com.exercicios.rest;

import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/time")
public class TimeFutebolController {

    private final List<Jogador> jogadores;

    public TimeFutebolController() {
        jogadores = new ArrayList<>();
        // Titulares (0-10)
        jogadores.add(new Jogador("Goleiro A", "Goleiro", 25));
        jogadores.add(new Jogador("Lateral D B", "Lateral Direito", 28));
        jogadores.add(new Jogador("Zagueiro C", "Zagueiro", 30));
        jogadores.add(new Jogador("Zagueiro D", "Zagueiro", 22));
        jogadores.add(new Jogador("Lateral E", "Lateral Esquerdo", 26));
        jogadores.add(new Jogador("Volante F", "Volante", 29));
        jogadores.add(new Jogador("Meia G", "Meia", 24));
        jogadores.add(new Jogador("Meia H", "Meia", 31));
        jogadores.add(new Jogador("Ponta I", "Ponta Direita", 20));
        jogadores.add(new Jogador("Ponta J", "Ponta Esquerda", 27));
        jogadores.add(new Jogador("Atacante K", "Centroavante", 33));

        // Reservas (11-20) - Requisito pede 5 reservas, mas a lista vai até 20, então vou colocar 10 para completar o array.
        jogadores.add(new Jogador("Reserva 1", "Goleiro", 19));
        jogadores.add(new Jogador("Reserva 2", "Zagueiro", 21));
        jogadores.add(new Jogador("Reserva 3", "Lateral", 23));
        jogadores.add(new Jogador("Reserva 4", "Volante", 25));
        jogadores.add(new Jogador("Reserva 5", "Meia", 27));
        jogadores.add(new Jogador("Reserva 6", "Atacante", 29));
        jogadores.add(new Jogador("Reserva 7", "Ponta", 20));
        jogadores.add(new Jogador("Reserva 8", "Zagueiro", 22));
        jogadores.add(new Jogador("Reserva 9", "Meia", 24));
        jogadores.add(new Jogador("Reserva 10", "Atacante", 26));
    }

    @GetMapping("/principal")
    public List<Jogador> getPrincipal() {
        return jogadores.subList(0, 11);
    }

    @GetMapping("/reservas")
    public List<Jogador> getReservas() {
        return jogadores.subList(11, jogadores.size());
    }

    @PutMapping("/jogador/{posicao}")
    public Jogador substituirJogador(@PathVariable int posicao) {
        if (posicao < 0 || posicao > 10) {
            return null;
        }

        if (jogadores.size() <= 11) {
            return null;
        }

        Jogador reserva = jogadores.remove(11);
        Jogador substituido = jogadores.set(posicao, reserva);

        jogadores.add(substituido);

        return reserva;
    }
}
